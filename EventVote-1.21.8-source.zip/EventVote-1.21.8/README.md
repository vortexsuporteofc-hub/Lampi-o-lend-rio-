# EventVote — Paper 1.21.8

Plugin-fonte para Paper 1.21.8 e Java 21.

## Recursos
- Placa interativa configurada com `/eventvote setplaca` (olhe para uma placa).
- Menu GUI; cada jogador vota uma vez por rodada.
- Eventos com MiniMessage: `<#FF5555>Torneio PvP` e `<gradient:#FF0000:#FFFF00>Evento especial</gradient>`.
- Resultado e anúncio do evento mais votado.
- Bloqueio de novas votações durante o evento; `/eventvote terminar` libera outra rodada.
- LuckPerms opcional: o plugin usa permissões Bukkit reconhecidas pelo LuckPerms.

## Compilar
Requer Java 21 e Maven 3.9+: `mvn clean package`.
Saída: `target/EventVote-1.21.8.jar`.
Também há GitHub Actions em `.github/workflows/build.yml`.

## Comandos
`/eventvote criar <nome>`, `/eventvote remover <id>`, `/eventvote lista`,
`/eventvote abrir`, `/eventvote fechar`, `/eventvote votar`, `/eventvote resultado`,
`/eventvote iniciar`, `/eventvote iniciar-evento <id>`, `/eventvote terminar`,
`/eventvote setplaca`, `/eventvote ajuda`.

## Permissões / LuckPerms
- `eventvote.vote` — votar (default true)
- `eventvote.create` — cadastrar/remover eventos
- `eventvote.manage` — abrir/fechar votação, iniciar/terminar evento e configurar placa
- `eventvote.admin` — tudo

Grupos pedidos:
```
/lp creategroup dono
/lp creategroup dev
/lp creategroup admin
/lp group dono permission set eventvote.admin true
/lp group dev permission set eventvote.create true
/lp group dev permission set eventvote.manage true
/lp group admin permission set eventvote.manage true
/lp user <jogador> parent set dono
```
Ajuste os membros/grupos conforme necessário.

## Limitações desta primeira versão
- Este ZIP é o código-fonte; ainda não é um JAR compilado nem testado em servidor.
- Os votos são mantidos em memória e são zerados ao reiniciar o servidor.
- O evento fica em andamento até um administrador executar `/eventvote terminar`.
- O menu mostra até 14 opções por vez.
