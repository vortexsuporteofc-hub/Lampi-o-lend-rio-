package br.com.eventvote;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class EventVotePlugin extends JavaPlugin implements Listener, CommandExecutor {
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Map<String, String> events = new LinkedHashMap<>();
    private final Map<String, Integer> votes = new HashMap<>();
    private final Map<UUID, String> playerVotes = new HashMap<>();
    private boolean votingOpen;
    private String runningEvent;
    private SignLocation voteSign;

    @Override public void onEnable() {
        saveDefaultConfig();
        loadData();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("eventvote")).setExecutor(this);
        getLogger().info("EventVote habilitado.");
    }
    @Override public void onDisable() { saveData(); }

    private void loadData() {
        if (getConfig().getConfigurationSection("events") != null) {
            for (String id : getConfig().getConfigurationSection("events").getKeys(false))
                events.put(id, getConfig().getString("events." + id, id));
        }
        votingOpen = getConfig().getBoolean("voting-open", false);
        runningEvent = getConfig().getString("running-event");
        if (getConfig().contains("vote-sign.world")) voteSign = new SignLocation(
            getConfig().getString("vote-sign.world"), getConfig().getInt("vote-sign.x"),
            getConfig().getInt("vote-sign.y"), getConfig().getInt("vote-sign.z"));
        // Votos de uma rodada não são restaurados após reinício.
        if (runningEvent != null && !events.containsKey(runningEvent)) runningEvent = null;
    }
    private void saveData() {
        getConfig().set("events", null);
        events.forEach((id, name) -> getConfig().set("events." + id, name));
        getConfig().set("voting-open", votingOpen);
        getConfig().set("running-event", runningEvent);
        if (voteSign != null) {
            getConfig().set("vote-sign.world", voteSign.world);
            getConfig().set("vote-sign.x", voteSign.x);
            getConfig().set("vote-sign.y", voteSign.y);
            getConfig().set("vote-sign.z", voteSign.z);
        }
        saveConfig();
    }
    private boolean allowed(CommandSender s, String node) {
        return s.hasPermission("eventvote.admin") || s.hasPermission(node);
    }
    private boolean deny(CommandSender s) { s.sendMessage("§cVocê não tem permissão."); return true; }
    private Component colored(String s) { return mini.deserialize(s == null ? "" : s); }
    private String plain(String s) { return PlainTextComponentSerializer.plainText().serialize(colored(s)); }
    private String makeId(String name) {
        String id = plain(name).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "-").replaceAll("-+", "-");
        return id.isBlank() ? "evento-" + (events.size() + 1) : id;
    }

    @Override public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("ajuda")) { help(s); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "criar" -> {
                if (!allowed(s, "eventvote.create")) return deny(s);
                if (a.length < 2) { s.sendMessage("§c/eventvote criar <nome colorido>"); return true; }
                String name = String.join(" ", Arrays.copyOfRange(a, 1, a.length));
                String id = makeId(name), unique = id; int n = 2;
                while (events.containsKey(unique)) unique = id + "-" + n++;
                events.put(unique, name); votes.put(unique, 0); saveData();
                s.sendMessage("§aEvento criado: " + plain(name) + " §7(ID: " + unique + ")");
            }
            case "remover" -> {
                if (!allowed(s, "eventvote.create")) return deny(s);
                if (a.length < 2 || !events.containsKey(a[1])) { s.sendMessage("§c/eventvote remover <id>"); return true; }
                events.remove(a[1]); votes.remove(a[1]); playerVotes.values().removeIf(a[1]::equals);
                if (Objects.equals(runningEvent, a[1])) runningEvent = null;
                saveData(); s.sendMessage("§aEvento removido.");
            }
            case "lista" -> {
                s.sendMessage("§6Eventos cadastrados:");
                if (events.isEmpty()) s.sendMessage("§7Nenhum evento cadastrado.");
                events.forEach((id, name) -> s.sendMessage("§e" + plain(name) + " §7(ID: " + id + ")"));
            }
            case "abrir" -> {
                if (!allowed(s, "eventvote.manage")) return deny(s);
                if (runningEvent != null) { s.sendMessage("§cA votação está bloqueada enquanto há um evento em andamento."); return true; }
                if (events.isEmpty()) { s.sendMessage("§cCadastre eventos primeiro."); return true; }
                votes.clear(); events.keySet().forEach(id -> votes.put(id, 0)); playerVotes.clear();
                votingOpen = true; saveData();
                Bukkit.broadcastMessage("§a§lVOTAÇÃO ABERTA! §fClique na placa ou use /eventvote votar.");
            }
            case "fechar" -> {
                if (!allowed(s, "eventvote.manage")) return deny(s);
                if (!votingOpen) { s.sendMessage("§cNão há votação aberta."); return true; }
                votingOpen = false; saveData(); announceResults();
            }
            case "votar" -> {
                if (!(s instanceof Player p)) { s.sendMessage("§cSomente jogadores podem votar."); return true; }
                openMenu(p);
            }
            case "resultado" -> showResults(s);
            case "iniciar" -> {
                if (!allowed(s, "eventvote.manage")) return deny(s);
                if (votingOpen || runningEvent != null) { s.sendMessage("§cFeche a votação e verifique se não há evento ativo."); return true; }
                String winner = winner();
                if (winner == null) { s.sendMessage("§cNão há votos/resultados para iniciar."); return true; }
                runningEvent = winner; saveData();
                Bukkit.broadcast(Component.text("§6§lEVENTO ESCOLHIDO: ").append(colored(events.get(winner))));
                Bukkit.broadcastMessage("§eNovas votações ficam bloqueadas até o evento terminar.");
            }
            case "iniciar-evento" -> {
                if (!allowed(s, "eventvote.manage")) return deny(s);
                if (a.length < 2 || !events.containsKey(a[1])) { s.sendMessage("§c/eventvote iniciar-evento <id>"); return true; }
                if (votingOpen || runningEvent != null) { s.sendMessage("§cJá existe votação ou evento em andamento."); return true; }
                runningEvent = a[1]; saveData();
                Bukkit.broadcast(Component.text("§6§lEVENTO INICIADO: ").append(colored(events.get(runningEvent))));
            }
            case "terminar" -> {
                if (!allowed(s, "eventvote.manage")) return deny(s);
                if (runningEvent == null) { s.sendMessage("§cNão há evento em andamento."); return true; }
                Bukkit.broadcast(Component.text("§a§lEVENTO FINALIZADO: ").append(colored(events.getOrDefault(runningEvent, runningEvent))));
                runningEvent = null; saveData(); Bukkit.broadcastMessage("§eUma nova votação pode ser aberta.");
            }
            case "setplaca" -> {
                if (!allowed(s, "eventvote.manage")) return deny(s);
                if (!(s instanceof Player p)) { s.sendMessage("§cUse dentro do jogo."); return true; }
                Block b = p.getTargetBlockExact(6);
                if (b == null || !(b.getState() instanceof Sign)) { p.sendMessage("§cOlhe para uma placa a até 6 blocos."); return true; }
                voteSign = new SignLocation(b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
                saveData(); p.sendMessage("§aPlaca configurada. Clique com o botão direito para votar.");
            }
            default -> help(s);
        }
        return true;
    }
    private void help(CommandSender s) {
        s.sendMessage("§6§lEventVote §7- comandos");
        s.sendMessage("§e/eventvote criar <nome> §7- cria evento (MiniMessage)");
        s.sendMessage("§e/eventvote remover <id> | lista");
        s.sendMessage("§e/eventvote abrir | fechar | votar | resultado");
        s.sendMessage("§e/eventvote iniciar §7- inicia o mais votado");
        s.sendMessage("§e/eventvote iniciar-evento <id> | terminar");
        s.sendMessage("§e/eventvote setplaca §7- registra a placa que você olha");
    }

    private void openMenu(Player p) {
        if (!allowed(p, "eventvote.vote")) { p.sendMessage("§cVocê não pode votar."); return; }
        if (!votingOpen || runningEvent != null) { p.sendMessage("§cNão há votação disponível agora."); return; }
        if (playerVotes.containsKey(p.getUniqueId())) { p.sendMessage("§cVocê já votou nesta rodada."); return; }
        Inventory inv = Bukkit.createInventory(new VoteHolder(), 27, Component.text("Votação de Eventos"));
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int i = 0;
        for (Map.Entry<String, String> e : events.entrySet()) {
            if (i >= slots.length) break;
            ItemStack item = new ItemStack(Material.PAPER);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(colored(e.getValue()));
            meta.lore(List.of(Component.text("§7Clique para votar"), Component.text("§eVotos: " + votes.getOrDefault(e.getKey(), 0))));
            item.setItemMeta(meta); inv.setItem(slots[i++], item);
        }
        p.openInventory(inv);
    }
    @EventHandler public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof VoteHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!votingOpen || runningEvent != null || playerVotes.containsKey(p.getUniqueId())) { p.closeInventory(); return; }
        ItemStack item = e.getCurrentItem();
        if (item == null || item.getType() != Material.PAPER || !item.hasItemMeta() || item.getItemMeta().displayName() == null) return;
        String shown = PlainTextComponentSerializer.plainText().serialize(item.getItemMeta().displayName());
        String id = events.entrySet().stream().filter(x -> plain(x.getValue()).equals(shown)).map(Map.Entry::getKey).findFirst().orElse(null);
        if (id == null) return;
        playerVotes.put(p.getUniqueId(), id); votes.merge(id, 1, Integer::sum);
        p.closeInventory(); p.sendMessage("§aVoto registrado para " + plain(events.get(id)) + "!");
    }
    @EventHandler public void onSign(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null || voteSign == null) return;
        Block b = e.getClickedBlock();
        if (!b.getWorld().getName().equals(voteSign.world) || b.getX() != voteSign.x || b.getY() != voteSign.y || b.getZ() != voteSign.z) return;
        e.setCancelled(true); openMenu(e.getPlayer());
    }
    private String winner() {
        return votes.entrySet().stream().filter(x -> events.containsKey(x.getKey()))
            .max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(null);
    }
    private void announceResults() {
        Bukkit.broadcastMessage("§6§lRESULTADO DA VOTAÇÃO");
        events.forEach((id, name) -> Bukkit.broadcastMessage("§e" + plain(name) + "§7: §f" + votes.getOrDefault(id, 0) + " votos"));
        String w = winner();
        if (w != null) Bukkit.broadcast(Component.text("§aMais votado: ").append(colored(events.get(w))));
        else Bukkit.broadcastMessage("§7Nenhum voto registrado.");
    }
    private void showResults(CommandSender s) {
        s.sendMessage("§6§lRESULTADO DA VOTAÇÃO");
        events.forEach((id, name) -> s.sendMessage("§e" + plain(name) + "§7: §f" + votes.getOrDefault(id, 0) + " votos"));
        if (runningEvent != null) s.sendMessage("§aEvento em andamento: " + plain(events.getOrDefault(runningEvent, runningEvent)));
        else s.sendMessage(votingOpen ? "§aVotação aberta." : "§7Votação fechada.");
    }
    private static final class VoteHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }
    private record SignLocation(String world, int x, int y, int z) {}
}
